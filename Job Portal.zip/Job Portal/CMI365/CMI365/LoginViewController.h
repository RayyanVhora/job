//
//  LoginViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JobsViewController.h"
#import "ModelClass.h"
#import "LLDataControll.h"
#import "AppDelegate.h"
@interface LoginViewController : UIViewController<UITextFieldDelegate>
{

    IBOutlet UITextField *txtUserId;
    IBOutlet UITextField *txtPassword;
    IBOutlet UILabel *lblUserName;
    IBOutlet UILabel *lblPassword;
    AppDelegate *mainDelegate;
    ModelClass *mc;
    LLDataControll *dc;
}
@property (retain, nonatomic) IBOutlet UIScrollView *scrollView;


- (IBAction)txtPasswordStart:(id)sender;
- (IBAction)txtPasswordDone:(id)sende;


@end
