//
//  JobDetailsViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "JobDetailsViewController.h"

@interface JobDetailsViewController ()

@end

@implementation JobDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil DataArray:(NSArray *)array Ispick:(BOOL)Ispick
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        dataArray=[[NSMutableArray alloc]initWithArray:array];
        NSLog(@"dictionary-->%d",[[[dataArray valueForKey:@"Collection"]objectAtIndex:1]count]);
         NSLog(@"%@",[dataArray objectAtIndex:3]);
        ispick=Ispick;
        if (Ispick) {
            NSLog(@"pick");
            header_lbl.text=@"Pick Detail";
            
            if (hedaing) {
                [hedaing removeAllObjects];
            }
            hedaing=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"CollectionAddress",@"Company",@"Building",@"Street",@"Locality",@"Town",@"Country",@"Postcode",@"Telephone",@"ReadyAt",@"NoLater",@"Notes",nil]];
             hedaing1=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"Collection Address",@"Company",@"Building",@"Street",@"Locality",@"Town",@"Country",@"Post Code",@"Telephone",@"Ready AT",@"NoLater",@"Notes",nil]];
            
            displayarr1 = [[NSMutableArray alloc]init];
            for (int i = 0; i<[[[dataArray valueForKey:@"Collection"]objectAtIndex:1]count] ;i++){
                for (int j = 0; j<[hedaing count]; j++) {
                [displayarr1 addObject:[NSString stringWithFormat:@"%@",[[[[[[dataArray objectAtIndex:1]valueForKey:@"Collection"]valueForKey:@"Pick"] objectAtIndex:i]objectAtIndex:0] valueForKey:[NSString stringWithFormat:@"%@",[hedaing objectAtIndex:j]]]]];
                }
        }
            if ([[[dataArray valueForKey:@"Collection"]objectAtIndex:1]count]>1) {
                
                for (int i = 0; i<[[[dataArray valueForKey:@"Collection"]objectAtIndex:1]count]-1 ;i++) {
                    [hedaing addObjectsFromArray:hedaing];
                    [hedaing1 addObjectsFromArray:hedaing1];
                }
            }
        }
        
        else{
            NSLog(@"Drop");
             header_lbl.text=@"Drop Detail";
        
             
            
            destDics=[[NSMutableDictionary alloc]initWithDictionary:[[[[[dataArray objectAtIndex:2]valueForKey:@"Destination"]valueForKey:@"Drop"] objectAtIndex:0]objectAtIndex:0]];
            
            if (hedaing) {
                [hedaing removeAllObjects];
            }
            
             if ([[[dataArray objectAtIndex:3]valueForKey:@"Pod"] count]>0) {
                PodDics=[[NSMutableDictionary alloc]initWithDictionary:[[[[[dataArray objectAtIndex:3]valueForKey:@"Pod"] objectAtIndex:0]valueForKey:@"OnePod"] objectAtIndex:0]];
                 
                NSLog(@"Archive drop");
                 hedaing=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"Pod Signed",@"Pod Date",@"DestinationAddress",@"Company",@"Building",@"Street",@"Locality",@"Town",@"Country",@"Postcode",@"Telephone",@"ReadyAt",@"NoLater",@"Notes",nil]];
                 hedaing1=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"Pod Signed",@"Pod Date",@"Destination Address", @"Company", @"Building",@"Street", @"Locality",@"Town",@"Country", @"Post Code", @"Telephone", @"Ready AT",@"NoLater",@"Notes",nil]];
                 
            }
            else{
                NSLog(@"Active drop");
                hedaing=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"DestinationAddress",@"Company",@"Building",@"Street",@"Locality",@"Town",@"Country",@"Postcode",@"Telephone",@"ReadyAt",@"NoLater",@"Notes",nil]];
                hedaing1=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"Destination Address",@"Company",@"Building",@"Street",@"Locality",@"Town",@"Country",@"Post Code",@"Telephone",@"Ready AT",@"NoLater",@"Notes",nil]];

            }
        
        }
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    if (ispick) {
        header_lbl.text=@"Pick Detail";
    }
    else{
         header_lbl.text=@"Drop Detail";
    }
    [tblJobDetail reloadData];
    //detail=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"1024,Fashion Street,NY 201,MG Road",@"Nexen Petroleum",@"Peterhead Offshore Supply Base",@"UK o+G Sc/Offshore Drilling",@"C/O Asco Ltd",@"Peterhead",@"United Kingdom",@"AB4F 2PF",@"+0 214 0451 789",@"",@"25/10/2012 23:59:00",@"C/O Asco Ltd",nil]];
    
    //NSLog(@"%@",hedaing);
    //NSLog(@"%@",detail);
    
    // Do any additional setup after loading the view from its nib.
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
     
   //NSLog(@"%@",destDics);
    //NSLog(@"%@",hedaing);
    //NSLog(@"%@",PodDics);
}
- (IBAction)btnBack:(id)sender {
    
     [self.navigationController popViewControllerAnimated:YES];
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return hedaing.count;
}

// Customize the appearance of table view cells.
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    

    
    UILabel *lblHeading = [[UILabel alloc] initWithFrame:CGRectMake(7,10, 150, 18)];
    lblHeading.backgroundColor = [UIColor clearColor];
    [lblHeading setTextColor:[UIColor colorWithRed:179.0/255.0 green:179.0/255.0 blue:179.0/255.0 alpha:1.0]];
    lblHeading.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:12];
    lblHeading.textAlignment = UITextAlignmentLeft;
    lblHeading.text = [hedaing1 objectAtIndex:indexPath.row];
    [cell.contentView addSubview:lblHeading];
    
    UILabel *lblDetail = [[UILabel alloc] initWithFrame:CGRectMake(7,25,300,20)];
    lblDetail.backgroundColor = [UIColor clearColor];
    [lblDetail setTextColor:[UIColor colorWithRed:60.0/255.0 green:60.0/255.0 blue:60.0/255.0 alpha:1.0]];
    lblDetail.font=[UIFont fontWithName:@"Helvetica-Bold" size:13];
    lblDetail.textAlignment = UITextAlignmentLeft;
    if (ispick) {
       
        for (int i = 0; i<[[[dataArray valueForKey:@"Collection"]objectAtIndex:1]count] ;i++){
            lblDetail.text = [displayarr1 objectAtIndex:indexPath.row];
           
        }
    }
    else{
        
        if (PodDics) {
            if (indexPath.row<=1) {
                lblDetail.text = [NSString stringWithFormat:@"%@",[PodDics valueForKey:[NSString stringWithFormat:@"%@",[hedaing objectAtIndex:indexPath.row]]]];
            }
            else{
                lblDetail.text = [NSString stringWithFormat:@"%@",[destDics valueForKey:[NSString stringWithFormat:@"%@",[hedaing objectAtIndex:indexPath.row]]]];
            }
        }
        
    else{
         lblDetail.text = [NSString stringWithFormat:@"%@",[destDics valueForKey:[NSString stringWithFormat:@"%@",[hedaing objectAtIndex:indexPath.row]]]];
        
    }
    }

    [cell.contentView addSubview:lblDetail];

    
    return cell;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblJobDetail release];
    [header_lbl release];
    [super dealloc];
}
- (void)viewDidUnload {
    [header_lbl release];
    header_lbl = nil;
    [super viewDidUnload];
}
@end
