//
//  ImageDownload.m
//  sinemaApp
//
//  Created by Patrascu Raluca on 4/3/10.
//  Copyright 2010 home. All rights reserved.
//

#import "ImageDownload.h"

@implementation ImageDownload
@synthesize idd,url,type;

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
		
		self.backgroundColor = [UIColor clearColor];
    }
	
    return self;
}

- (void)drawRect:(CGRect)rect {
	
	self.backgroundColor = [UIColor clearColor];
	image=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
	image.backgroundColor = [UIColor clearColor];
	image.contentMode=UIViewContentModeScaleAspectFit;
	[self addSubview:image];
	[image release];
	
    
	activity = [[UIActivityIndicatorView alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
	if([type isEqual:@"place_small"] || [type isEqual:@"places_small_api"] || [type isEqual:@"team_small"] || [type isEqual:@"player_small"])
	{
		activity.frame=CGRectMake(0, 0, 15, 15);
        activity.activityIndicatorViewStyle=UIActivityIndicatorViewStyleGray;
	}
    else
        activity.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
	activity.center = image.center;
	[activity startAnimating];
	[self addSubview:activity];
	[activity release];
	
	NSFileManager *defaultManger = [NSFileManager defaultManager];
	NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%@",type,idd]];
	
    
	if([defaultManger fileExistsAtPath:path])
	{		
		image.image =[UIImage imageWithData:[NSData dataWithContentsOfFile:path]]; 
		[activity removeFromSuperview];
	}
	else
	{
		dataDidLoad = 0;
		
		[[NSRunLoop currentRunLoop] addTimer:[NSTimer timerWithTimeInterval:0.1 target:self selector:@selector(check:) userInfo:nil repeats:YES] forMode:NSDefaultRunLoopMode];
		[NSThread detachNewThreadSelector:@selector(downloadThisImage:) toTarget:self withObject:[NSString stringWithFormat:@"%@|||%@",idd,url]];
	}
}

-(void)downloadThisImage:(NSString*)sender
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc]init];
	
	NSFileManager *defaultManager = [NSFileManager defaultManager];
	
	NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
	
	NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%@",type,idd]];
	[defaultManager createFileAtPath:path contents:nil attributes:[[NSDictionary alloc]init]];
	[data writeToFile:path atomically:YES]; 
	dataDidLoad = 1;
	[pool release];
}

-(void)check:(NSTimer*)sender
{
	if(dataDidLoad == 1)
	{
		[sender invalidate];
		
		[activity removeFromSuperview];
		
		NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%@",type,idd]];
		
		image.image=[UIImage imageWithData:[NSData dataWithContentsOfFile:path]];
	}
}

- (void)dealloc {
    [super dealloc];
}


@end
