//
//  ActivejobsViewController.h
//  CMI365
//
//  Created by iMac on 11/6/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChooseOptionViewController.h"
#import "LLDataControll.h"
#import "AppDelegate.h"
#import "ModelClass.h"
@interface ActivejobsViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    
    
    IBOutlet UITableView *tblListing;
    
    NSMutableArray *jobArray;
    NSMutableArray *accountArray;
    NSMutableArray *docketNoArray;
    NSMutableArray *job_add_id_arr;
    NSMutableArray *job_add_arr;
    NSMutableArray *statusarray;
    NSMutableArray *updatedarray;
    LLDataControll *dc;
    AppDelegate *mainDelegate;
    ModelClass *mc;

    
}

@end
