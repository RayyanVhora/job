//
//  JobsViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JobListingViewController.h"
#import "LoginViewController.h"
#import "LLDataControll.h"
#import "AppDelegate.h"
#import "ModelClass.h"
#import <CoreLocation/CoreLocation.h>
#import <AudioToolbox/AudioToolbox.h>

@interface JobsViewController : UIViewController
{
    LLDataControll *dc;
    AppDelegate *mainDelegate;
    ModelClass *mc;
}
- (IBAction)logout:(id)sender;

@end
