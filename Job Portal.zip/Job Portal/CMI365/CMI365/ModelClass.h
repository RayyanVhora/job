//
//  ModelClass.h
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SBJson.h"
#import "DarckWaitView.h"
#import "LLDataControll.h"
@class DarckWaitView;

@interface ModelClass : NSObject {
    SBJsonParser *parser;
    SEL seignInSel;
    SEL seignUpSel;
    SEL subCatSel;
    SEL sublistSel;
    SEL statchSel;
    SEL historySel;
    SEL celebretySel;
    SEL ForgotPass;
    SEL TodayPrice;
    SEL EnterContest;
    SEL GetCard;
    SEL MyGifts;
    SEL GetCarddetails;
    SEL Applypoints;
    SEL GetPoints;
    SEL EditEmail;
    SEL callbackGainPoints;
    SEL  noReferralUser;
    SEL  ChangePass;
    SEL  isShare;
    //-----------------
    SEL  Login;
    SEL  NewJob;
    SEL Activejobs;
    SEL Archivejobs;
    SEL Confirmjobs;
    SEL Declinejobs;
    SEL jobDropOrDetail;
    
    SEL savepob;
    SEL savepod;
    NSString *temp;
    DarckWaitView *drk;
    DarckWaitView *drkSignUp;
    LLDataControll *dc;
}
@property (nonatomic, retain)  NSString *temp;
@property (nonatomic, retain) id delegate;
@property (nonatomic, retain) id returnData;
@property (nonatomic, readwrite) BOOL success;
- (void) signIn:(NSString *)email password:(NSString *)pasw selector:(SEL)sel;
- (NSArray *) getCategories;
- (void) getSubCategoriesForCatId:(NSInteger)catId selector:(SEL)sel;
- (void)getSublistForSubCatId:(NSInteger)catId selector:(SEL)sel;
- (void)getHistoryForCelebrity:(NSInteger)celId selector:(SEL)sel;
- (void)getCelebrityForID:(NSInteger)celId selector:(SEL)sel;

-(void) TodayPrice:(SEL)sel;
-(NSArray *) getWhoSnaches;

- (void) frlist:(NSString *)ide name:(NSString *)nm picture:(NSString *)photo gender:(NSString *)gdr birthday:(NSString *)bdate selector:(SEL)sel;

- (void)signUpEmail:(NSString *)email password:(NSString *)pasw Fname:(NSString *)fname Lname:(NSString *)lname Partner:(NSString *)partner Referralid:(NSString *)referralid Phone:(NSString *)phone Deviceid:(NSString *)deviceid selector:(SEL)sel;

-(void)EnterContest:(NSString*)email ContestId:(NSString*)contestid UserId:(NSString*)userid CardQuntity:(NSString*)card selector:(SEL)sel;

-(void)ForgotPass:(NSString*)email selector:(SEL)sel;

-(void) GetCard:(NSString *)userid selector:(SEL)sel;

-(void) MyGifts:(NSString *)userid selector:(SEL)sel;

-(void) GetCardDetail:(NSString *)userid Cardid:(NSString *)cardid Chk:(NSString *)chk selector:(SEL)sel;

-(void) GetPoints:(NSString *)userid;

-(void) SetPoints:(NSString *)userid Reward:(NSString *)reward;

-(void) EditEmail:(NSString *)userid User_Email:(NSString *)userEmail selector:(SEL)sel;

-(void) ApplyPoints:(NSString *)userid CardId:(NSString *)cardid Completed:(NSString *)completed Chk:(NSString *)chk Email:(NSString *)email PtsApplied:(NSString *)applied PtsRequired:(NSString *)required  selector:(SEL)sel;
- (NSString *) getFunc:(NSURL *)url;

-(void)callbackGainPoints:(NSString*)Userid Type:(NSString*)type selector:(SEL)sel;
-(void)noReferralUser:(NSString*)Userid selector:(SEL)sel;

-(void) ChangePass:(NSString *)userid PassWord:(NSString *)password selector:(SEL)sel;

- (BOOL) validateEmail: (NSString *)candidate;
//- (NSString *) getFunc:(NSURL *)url;
-(void) GetPoints:(NSString *)userid Activity:(BOOL)Activity;
- (void) gosnatchWithCelebrity:(NSInteger)celId userId:(NSInteger)userId prise:(NSInteger)price selector:(SEL)sel;
-(void)setPoints:(NSString *)user_id;
-(void)isShare:(NSString*)user_id selector:(SEL)sel;

//------------------------------------------------------
-(void)login:(NSString*)username Password:(NSString*)pass selector:(SEL)sel;

-(void)newjobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel;

-(void)activejobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel;

-(void)archivejobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel;

-(void)confirmORDeclinejobs:(NSString*)username Password:(NSString*)pass Jobnum:(NSString*)num Status:(NSString*)status selector:(SEL)sel;
-(void)jobDetailOrJobDetail:(NSString*)username Password:(NSString*)pass Jobnum:(NSString*)num Status:(NSString*)status selector:(SEL)sel;



-(void)pobSave:(NSString*)username Password:(NSString*)pass job_num:(NSString*)jobnum pob_date:(NSString*)pobdate pob_time:(NSString*)pobtime selector:(SEL)sel;

-(void)podSave:(NSString*)username Password:(NSString*)pass job_num:(NSString*)jobnum job_add_id:(NSString*)jobaddid pob_date:(NSString*)pobdate pob_time:(NSString*)pobtime Sign:(NSString*)sign selector:(SEL)sel;
@end
