//
//  ChooseOptionViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "ChooseOptionViewController.h"

@interface ChooseOptionViewController ()

@end

@implementation ChooseOptionViewController

@synthesize jobNum,job_add,job_add_id;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    lblPOD.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    [lblPOD setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblPOD.textAlignment=UITextAlignmentCenter;
     lblPOB.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    [lblPOB setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblPOB.textAlignment=UITextAlignmentCenter;
     lblPickDetails.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    [lblPickDetails setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblPickDetails.textAlignment=UITextAlignmentCenter;
     lblDropDetails.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    [lblDropDetails setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblDropDetails.textAlignment=UITextAlignmentCenter;
    
    dc=[[LLDataControll alloc]init];
    mc=[[ModelClass alloc]init];
    
    UITapGestureRecognizer *Tappodsave = [[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Tappodsave)] autorelease];
    [podsave addGestureRecognizer:Tappodsave];
    UITapGestureRecognizer *Tappobsave = [[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Tappobsave)] autorelease];
    [pobsave addGestureRecognizer:Tappobsave];
    
    timepickerview.frame = CGRectMake(0, 480, 320, 260);
	timepickerview.hidden = TRUE;
    timepicker.datePickerMode = UIDatePickerModeTime;
	[timepickerview addSubview:timepicker];
    [self.view addSubview:timepickerview];
    
    datepickerview.frame = CGRectMake(0, 480, 320, 260);
	datepickerview.hidden = TRUE;
    datepicker.datePickerMode = UIDatePickerModeDate;
	[datepickerview addSubview:datepicker];
    [self.view addSubview:datepickerview];
    
    droppickerview.frame = CGRectMake(0, 480, 320, 260);
	droppickerview.hidden = TRUE;
	[droppickerview addSubview:droppicker];
    [self.view addSubview:droppickerview];
    
    //pob
    
    pobtimepickerview.frame = CGRectMake(0, 480, 320, 260);
	pobtimepickerview.hidden = TRUE;
    pobtimepicker.datePickerMode = UIDatePickerModeTime;
	[pobtimepickerview addSubview:pobtimepicker];
    [self.view addSubview:pobtimepickerview];
    
    pobdatepickerview.frame = CGRectMake(0, 480, 320, 260);
	pobdatepickerview.hidden = TRUE;
    pobdatepicker.datePickerMode = UIDatePickerModeDate;
	[pobdatepickerview addSubview:pobdatepicker];
    [self.view addSubview:pobdatepickerview];
    
    DocketText.text=jobNum;
    pobDocket.text=jobNum;
    
    droptext.text=[job_add objectAtIndex:0];
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"hh:mm a"];
	selPodTime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:timepicker.date]];
    
    NSDateFormatter *df1 = [[NSDateFormatter alloc] init];
    [df1 setDateFormat:@"dd/MM/yyyy"];
	selPodDate.text = [NSString stringWithFormat:@"%@",[df1 stringFromDate:datepicker.date]];
    
    pobdate.text = [NSString stringWithFormat:@"%@",[df1 stringFromDate:datepicker.date]];
    pobtime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:timepicker.date]];
    
    // Do any additional setup after loading the view from its nib.
}

-(void)Tappodsave{
    
    selPodDate.userInteractionEnabled = YES;
    selPodTime.userInteractionEnabled = YES;
    droptext.userInteractionEnabled = YES;
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
          
            
            [mc podSave:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] job_num:jobNum job_add_id:[job_add_id objectAtIndex:[job_add indexOfObject:droptext.text]] pob_date:selPodDate.text pob_time:[[selPodTime.text componentsSeparatedByString:@" "] objectAtIndex:0] Sign:signText.text  selector:@selector(didPodsave:)];
            [podView removeFromSuperview];
            
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
}


-(void)Tappobsave{
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"jobNum->%@",pobtime.text);
     
            [mc pobSave:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] job_num:jobNum pob_date:pobdate.text pob_time:[[pobtime.text componentsSeparatedByString:@" "] objectAtIndex:0] selector:@selector(didPobsave:)];
            [pobView removeFromSuperview];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
}





-(void)didPodsave:(NSString*)dic{
    
    
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:dic message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [al show];
    [al release];
    
}
-(void)didPobsave:(NSString*)dic{
   
   
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:dic message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [al show];
    [al release];
    
}

- (IBAction)btnBack:(id)sender {
    
     [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)pickDetails:(id)sender {
    /*JobDetailsViewController *jobDetail=[[JobDetailsViewController alloc]initWithNibName:@"JobDetailsViewController" bundle:nil];
    [self.navigationController pushViewController:jobDetail animated:YES];*/
    
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"jobNum->%@",jobNum);
            
            
            [mc jobDetailOrJobDetail:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:jobNum Status:@"Confirmed" selector:@selector(didjobDetail:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
}

-(void)didjobDetail:(NSMutableDictionary*)dic{
    JobDetailsViewController *jobdetail=[[JobDetailsViewController alloc]initWithNibName:@"JobDetailsViewController" bundle:nil DataArray:[NSArray arrayWithArray:[dic valueForKey:@"Details"]]Ispick:YES];
    
    [self.navigationController pushViewController:jobdetail animated:YES];
    
}

- (IBAction)DropDetail:(UIButton *)sender {
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"jobNum->%@",jobNum);
            
            [mc jobDetailOrJobDetail:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:jobNum Status:@"Confirmed" selector:@selector(didjobDrop:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
}

-(void)didjobDrop:(NSMutableDictionary*)dic{
    
    NSLog(@"-->%@",dic);
    
    // NSLog(@"-->%@",[[dic valueForKey:@"Details"] valueForKey:@"Destination"]);
    //NSLog(@"-->%@",[NSArray arrayWithArray:[dic valueForKey:@"Details"]]);
    
    JobDetailsViewController *jobdetail=[[JobDetailsViewController alloc]initWithNibName:@"JobDetailsViewController" bundle:nil DataArray:[NSArray arrayWithArray:[dic valueForKey:@"Details"]]Ispick:NO];
    
    [self.navigationController pushViewController:jobdetail animated:YES];
    
}
- (IBAction)ClickPob:(UIButton *)sender {
    
    pobView.frame=CGRectMake(0,50,320,460);
    pobView.clipsToBounds=YES;
    [self.view addSubview:pobView];
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    
    CATransform3D scale1 = CATransform3DMakeScale(0.5, 0.5, 1);
    CATransform3D scale2 = CATransform3DMakeScale(1.2, 1.2, 1);
    CATransform3D scale3 = CATransform3DMakeScale(0.9, 0.9, 1);
    CATransform3D scale4 = CATransform3DMakeScale(1.0, 1.0, 1);
    
    NSArray *frameValues = [NSArray arrayWithObjects:
                            [NSValue valueWithCATransform3D:scale1],
                            [NSValue valueWithCATransform3D:scale2],
                            [NSValue valueWithCATransform3D:scale3],
                            [NSValue valueWithCATransform3D:scale4],
                            nil];
    [animation setValues:frameValues];
    
    NSArray *frameTimes = [NSArray arrayWithObjects:
                           [NSNumber numberWithFloat:0.0],
                           [NSNumber numberWithFloat:0.5],
                           [NSNumber numberWithFloat:0.9],
                           [NSNumber numberWithFloat:1.0],
                           nil];
    [animation setKeyTimes:frameTimes];
    
    animation.fillMode = kCAFillModeForwards;
    animation.removedOnCompletion = NO;
    animation.duration = .3;
    [pobView.layer addAnimation:animation forKey:@"popup"];
   
}


- (IBAction)ClickPod:(UIButton *)sender {
    
    podView.frame=CGRectMake(0,50,320,460);
    podView.clipsToBounds=YES;
    [self.view addSubview:podView];
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"transform"];
    
    CATransform3D scale1 = CATransform3DMakeScale(0.5, 0.5, 1);
    CATransform3D scale2 = CATransform3DMakeScale(1.2, 1.2, 1);
    CATransform3D scale3 = CATransform3DMakeScale(0.9, 0.9, 1);
    CATransform3D scale4 = CATransform3DMakeScale(1.0, 1.0, 1);
    
    NSArray *frameValues = [NSArray arrayWithObjects:
                            [NSValue valueWithCATransform3D:scale1],
                            [NSValue valueWithCATransform3D:scale2],
                            [NSValue valueWithCATransform3D:scale3],
                            [NSValue valueWithCATransform3D:scale4],
                            nil];
    [animation setValues:frameValues];
    
    NSArray *frameTimes = [NSArray arrayWithObjects:
                           [NSNumber numberWithFloat:0.0],
                           [NSNumber numberWithFloat:0.5],
                           [NSNumber numberWithFloat:0.9],
                           [NSNumber numberWithFloat:1.0],
                           nil];
    [animation setKeyTimes:frameTimes];
    
    animation.fillMode = kCAFillModeForwards;
    animation.removedOnCompletion = NO;
    animation.duration = .3;
    
    [podView.layer addAnimation:animation forKey:@"popup"];
    
    
}


-(void)showtimepickerView
{
    [self hidedroppickeView];
    [self hidedatepickeView];
    [signText resignFirstResponder];
	timepickerview .hidden = FALSE;
	CGRect frame = timepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 200;
	timepickerview .frame = frame;
	[UIView commitAnimations];
    
    [self.view bringSubviewToFront:timepickerview];
}




-(void)hidetimepickeView
{
	//pickerView.hidden = TRUE;
	CGRect frame = timepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 480;
	timepickerview.frame = frame;
	[UIView commitAnimations];
    [podScrollview setContentOffset:CGPointMake(0, 0)];
}


-(IBAction)clicktimepickeCanel:(id)sender
{
	[self hidetimepickeView];
}

-(IBAction)clicktimepickeDone:(id)sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"hh:mm a"];
    
	selPodTime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:timepicker.date]];
    [self hidetimepickeView];
    
}

- (IBAction)timepickervaluechange:(UIDatePicker *)sender {
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"hh:mm a"];
    
	selPodTime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:timepicker.date]];
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    NSLog(@"%@",textField.text);
    [textField resignFirstResponder];
}
//date picker

-(void)showdatepickerView
{
    NSLog(@"hhhhhiiiii");
    [self hidetimepickeView];
    [self hidedroppickeView];
    [signText resignFirstResponder];
    [signText endEditing:YES];
    
	datepickerview .hidden = FALSE;
	CGRect frame = datepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 200;
	datepickerview .frame = frame;
	[UIView commitAnimations];
    [self.view bringSubviewToFront:datepickerview];
    
    
}




-(void)hidedatepickeView
{
	//pickerView.hidden = TRUE;
	CGRect frame = datepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 480;
	datepickerview.frame = frame;
	[UIView commitAnimations];
}


-(IBAction)clickdatepickeCanel:(id)sender
{
	[self hidedatepickeView];
}

-(IBAction)clickdatepickeDone:(id)sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd/MM/yyyy"];
    
	selPodDate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:datepicker.date]];
    [self hidedatepickeView];
    
}

- (IBAction)datepickervaluechange:(UIDatePicker *)sender {
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd/MM/yyyy"];
    
	selPodDate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:datepicker.date]];
}





//drop picker

-(void)showdroppickerView
{
    [self hidedatepickeView];
    [self hidetimepickeView];
    [signText resignFirstResponder];
	droppickerview .hidden = FALSE;
	CGRect frame = droppickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 200;
	droppickerview .frame = frame;
	[UIView commitAnimations];
    
    [self.view bringSubviewToFront:droppickerview];
}




-(void)hidedroppickeView
{
	//pickerView.hidden = TRUE;
	CGRect frame = droppickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 480;
	droppickerview.frame = frame;
	[UIView commitAnimations];
}


-(IBAction)clickdroppickeCanel:(id)sender
{
	[self hidedroppickeView];
}

-(IBAction)clickdroppickeDone:(id)sender
{
   
    [self hidedroppickeView];
    
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component {
    // Handle the selection
    droptext.text=[NSString stringWithFormat:@"%@",[job_add objectAtIndex:row]];
}

// tell the picker how many rows are available for a given component
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
   
    
    return [job_add count];
}

// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

// tell the picker the title for a given component
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    NSString *title;
    title = [NSString stringWithFormat:@"%@",[job_add objectAtIndex:row]];
    
    return title;
}

// tell the picker the width of each row for a given component
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    int sectionWidth = 300;
    
    return sectionWidth;
}





//pob

-(void)pobshowtimepickerView
{
    
	pobtimepickerview .hidden = FALSE;
	CGRect frame = pobtimepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 200;
	pobtimepickerview .frame = frame;
	[UIView commitAnimations];
    
    [self.view bringSubviewToFront:pobtimepickerview];
}




-(void)pobhidetimepickeView
{
	//pickerView.hidden = TRUE;
	CGRect frame = pobtimepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 480;
	pobtimepickerview.frame = frame;
	[UIView commitAnimations];
}


-(IBAction)pobclicktimepickeCanel:(id)sender
{
	[self pobhidetimepickeView];
}

-(IBAction)pobclicktimepickeDone:(id)sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"hh:mm a"];
	pobtime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:pobtimepicker.date]];
    [self pobhidetimepickeView];
    
}

- (IBAction)pobtimepickervaluechange:(UIDatePicker *)sender {
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"hh:mm a"];
    
	pobtime.text = [NSString stringWithFormat:@"%@",[df stringFromDate:pobtimepicker.date]];
}


//date picker

-(void)pobshowdatepickerView
{
    [self pobhidetimepickeView];
    pobdatepickerview .hidden = FALSE;
	CGRect frame = pobdatepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 200;
	pobdatepickerview .frame = frame;
	[UIView commitAnimations];
    [self.view bringSubviewToFront:pobdatepickerview];
}




-(void)pobhidedatepickeView
{
    
	//pickerView.hidden = TRUE;
	CGRect frame = pobdatepickerview.frame;
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:.5];
	frame.origin.y = 480;
	pobdatepickerview.frame = frame;
	[UIView commitAnimations];
}


-(IBAction)pobclickdatepickeCanel:(id)sender
{
	[self pobhidedatepickeView];
}

-(IBAction)pobclickdatepickeDone:(id)sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd/MM/yyyy"];
    
	pobdate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:pobdatepicker.date]];
    [self pobhidedatepickeView];
    
}

- (IBAction)pobdatepickervaluechange:(UIDatePicker *)sender {
    
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"dd/MM/yyyy"];
    
	pobdate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:pobdatepicker.date]];
}



- (IBAction)pobdate:(UITextField *)sender {
    
    [self pobshowdatepickerView];
    [pobdate resignFirstResponder];
}

- (IBAction)pobtime:(UITextField *)sender {
    
    [self pobshowtimepickerView];
    [sender resignFirstResponder];
}

- (IBAction)poddate:(UITextField *)sender {
    
    [self showdatepickerView];
    [sender resignFirstResponder];
    
}

- (IBAction)podtime:(id)sender {
    
    [self showtimepickerView];
    [podScrollview setContentOffset:CGPointMake(0, 40)];
    [sender resignFirstResponder];
      
}



- (IBAction)dropdidbegin:(UITextField *)sender {
    [self showdroppickerView];
    [sender resignFirstResponder];
      
}

- (IBAction)close:(UIButton *)sender {
    selPodDate.userInteractionEnabled = YES;
    selPodTime.userInteractionEnabled = YES;
    droptext.userInteractionEnabled = YES;
    [pobView removeFromSuperview];
     [podView removeFromSuperview];
}


- (IBAction)sign:(UITextField *)sender {
    selPodDate.userInteractionEnabled = NO;
    selPodTime.userInteractionEnabled = NO;
    droptext.userInteractionEnabled = NO;
    [podScrollview setContentSize:CGSizeMake(290, 400)];
    [podScrollview setContentOffset:CGPointMake(0, 32)];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
     [podScrollview setContentSize:CGSizeMake(290, 248)];
     [podScrollview setContentOffset:CGPointMake(0, 0)];
    if (textField == signText) {
        selPodDate.userInteractionEnabled = YES;
        selPodTime.userInteractionEnabled = YES;
        droptext.userInteractionEnabled = YES;
    }
    return YES;
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [lblPOD release];
    [lblPOB release];
    [lblPickDetails release];
    [lblDropDetails release];
    [podView release];
    [podScrollview release];
    [selPodDate release];
    [selPodTime release];
    [signText release];
    [DocketText release];
    [pobView release];
    [pobDocket release];
    [pobdate release];
    [pobtime release];
    [podsave release];
    [pobsave release];
    [timepickerview release];
    [datepickerview release];
    [datepicker release];
    [timepicker release];
    [droptext release];
    [droppickerview release];
    [droppicker release];
    [pobdatepickerview release];
    [pobtimepickerview release];
    [pobdatepicker release];
    [pobtimepicker release];
    [super dealloc];
}
- (void)viewDidUnload {
    [lblPOD release];
    lblPOD = nil;
    [lblPOB release];
    lblPOB = nil;
    [lblPickDetails release];
    lblPickDetails = nil;
    [lblDropDetails release];
    lblDropDetails = nil;
    [podView release];
    podView = nil;
    [podScrollview release];
    podScrollview = nil;
    [selPodDate release];
    selPodDate = nil;
    [selPodTime release];
    selPodTime = nil;
    [signText release];
    signText = nil;
    [DocketText release];
    DocketText = nil;
    [pobView release];
    pobView = nil;
    [pobDocket release];
    pobDocket = nil;
    [pobdate release];
    pobdate = nil;
    [pobtime release];
    pobtime = nil;
    [podsave release];
    podsave = nil;
    [pobsave release];
    pobsave = nil;
    [timepickerview release];
    timepickerview = nil;
    [datepickerview release];
    datepickerview = nil;
    [datepicker release];
    datepicker = nil;
    [timepicker release];
    timepicker = nil;
    [droptext release];
    droptext = nil;
    [droppickerview release];
    droppickerview = nil;
    [droppicker release];
    droppicker = nil;
    [pobdatepickerview release];
    pobdatepickerview = nil;
    [pobtimepickerview release];
    pobtimepickerview = nil;
    [pobdatepicker release];
    pobdatepicker = nil;
    [pobtimepicker release];
    pobtimepicker = nil;
    [super viewDidUnload];
}
@end
