//
//  ActivejobsViewController.m
//  CMI365
//
//  Created by iMac on 11/6/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "ActivejobsViewController.h"
#import "Toast+UIView.h"
@interface ActivejobsViewController ()

@end

@implementation ActivejobsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dc=[[LLDataControll alloc]init];
    mc=[[ModelClass alloc]init];
    
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
            
            [mc activejobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] selector:@selector(didGetactivejobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }

    // Do any additional setup after loading the view from its nib.
}

-(void)didGetactivejobs:(NSDictionary*)dic{
  
    accountArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"account"]];
    
    docketNoArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"docketNo"]];
    
   job_add_id_arr=[[NSMutableArray alloc ]initWithArray:[[[dic valueForKey:@"docket"] valueForKey:@"dropAddress"] valueForKey:@"Job_add_id"]];
    job_add_arr=[[NSMutableArray alloc ]initWithArray:[[[dic valueForKey:@"docket"] valueForKey:@"dropAddress"] valueForKey:@"Address"]];
    statusarray = [[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"status"]];
    updatedarray = [[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"updated"]];
    
    
    [tblListing reloadData];
    
    if ([accountArray  count]>=1) {
        [tblListing reloadData];
    }
    
    else{
        [self.view makeToast:@"No Active job avalable"
                    duration:2.0
                    position:@"bottom"];
        
    }
    
}



- (IBAction)btnBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [docketNoArray count];
}

// Customize the appearance of table view cells.
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    UILabel *lblList = [[UILabel alloc] initWithFrame:CGRectMake(15, 12, 200, 41)];
    lblList.backgroundColor = [UIColor clearColor];
    [lblList setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblList.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    lblList.textAlignment = UITextAlignmentLeft;
    lblList.text = [NSString stringWithFormat:@"%@ - %@",[docketNoArray objectAtIndex:indexPath.row],[accountArray objectAtIndex:indexPath.row]];
    [cell.contentView addSubview:lblList];
    
    CGSize textSize = [lblList.text sizeWithFont:[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16]];
    
    UILabel *lblList1 = [[UILabel alloc] initWithFrame:CGRectMake(textSize.width+17, 7, 100, 41)];
    lblList1.backgroundColor = [UIColor clearColor];
    [lblList1 setTextColor:[UIColor blueColor]];
    lblList1.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:14];
    lblList1.textAlignment = UITextAlignmentLeft;
    if ([[updatedarray objectAtIndex:indexPath.row ] isEqualToString:@"False"]) {
      lblList1.text = [NSString stringWithFormat:@"%@",[statusarray objectAtIndex:indexPath.row]];   
    }
    else{
    lblList1.text = @"Updated";
    }
    [cell.contentView addSubview:lblList1];

    
    UIImageView *MyImageView = [[UIImageView alloc] initWithFrame:CGRectMake(290,20, 11, 15)];
    MyImageView.image = [UIImage imageNamed:@"Arrow@2x.png"];
    [cell.contentView addSubview: MyImageView];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblListing deselectRowAtIndexPath:indexPath animated:YES];
    
    ChooseOptionViewController *option=[[ChooseOptionViewController alloc]initWithNibName:@"ChooseOptionViewController" bundle:nil];
    option.jobNum=[docketNoArray objectAtIndex:indexPath.row];
    option.job_add_id=[job_add_id_arr objectAtIndex:0];
     option.job_add=[job_add_arr objectAtIndex:0];
    [self.navigationController pushViewController:option animated:YES];
    
    
}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblListing release];
    [super dealloc];
}
- (void)viewDidUnload {
    [tblListing release];
    tblListing = nil;
    [super viewDidUnload];
}
@end
