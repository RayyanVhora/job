//
//  ChooseOptionViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JobDetailsViewController.h"
#import "LLDataControll.h"
#import "ModelClass.h"
#import <QuartzCore/QuartzCore.h>
@interface ChooseOptionViewController : UIViewController<UITextFieldDelegate, UIActionSheetDelegate, UIScrollViewDelegate, UIAlertViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextViewDelegate>
{

    NSMutableArray *job_add;
    NSMutableArray *job_add_id;
    
    
    IBOutlet UILabel *lblPOD;

    IBOutlet UILabel *lblPOB;

    IBOutlet UILabel *lblPickDetails;

    IBOutlet UILabel *lblDropDetails;
    
    LLDataControll *dc;
    ModelClass *mc;
    
    NSString *jobNum;
    
    IBOutlet UIScrollView *podScrollview;
    IBOutlet UIView *podView;
    
    IBOutlet UITextField *selPodDate;
    
    IBOutlet UITextField *selPodTime;
    
    IBOutlet UITextField *signText;
    
    IBOutlet UITextField *droptext;
    IBOutlet UITextField *DocketText;
  
    IBOutlet UIView *pobView;
    IBOutlet UITextField *pobDocket;
    IBOutlet UITextField *pobdate;
    IBOutlet UITextField *pobtime;
    
    IBOutlet UILabel *podsave;
    IBOutlet UILabel *pobsave;
    
    IBOutlet UIView *timepickerview;
    IBOutlet UIView *datepickerview;
    IBOutlet UIView *droppickerview;
    
    IBOutlet UIDatePicker *datepicker;
    IBOutlet UIDatePicker *timepicker;
    IBOutlet UIPickerView *droppicker;
    //pob
    
    IBOutlet UIView *pobdatepickerview;
    IBOutlet UIView *pobtimepickerview;
    IBOutlet UIDatePicker *pobdatepicker;
    IBOutlet UIDatePicker *pobtimepicker;
    
    
}
@property(nonatomic,retain) NSMutableArray *job_add;
@property(nonatomic,retain)NSMutableArray *job_add_id;
@property (nonatomic,retain)NSString *jobNum;;
@end
