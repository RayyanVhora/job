//
//  ArchiveViewController.h
//  CMI365
//
//  Created by iMac on 11/6/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLDataControll.h"
#import "AppDelegate.h"
#import "ModelClass.h"
@interface ArchiveViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>{
    
    IBOutlet UITableView *tblListing;
    NSMutableArray *jobArray;
    NSMutableArray *accountArray;
    NSMutableArray *docketNoArray;
    
    LLDataControll *dc;
    AppDelegate *mainDelegate;
    ModelClass *mc;
    IBOutlet UIView *optionview;
    
}

@end
