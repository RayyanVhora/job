//
//  ViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
#import "LLDataControll.h"
#import "JobsViewController.h"
@interface ViewController : UIViewController{
    LLDataControll *dc;
}

@end
