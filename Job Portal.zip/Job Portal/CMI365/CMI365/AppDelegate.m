//
//  AppDelegate.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"

@implementation AppDelegate
@synthesize loadingView;
- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil] autorelease];
   // self.window.rootViewController = self.viewController;
    UINavigationController *navigation =[[UINavigationController alloc]initWithRootViewController:self.viewController];
    navigation.navigationBar.hidden=YES;
    self.window.rootViewController = navigation;
    [self.window makeKeyAndVisible];
    return YES;
}


-(BOOL)isHostAvailable
{
	/*Reachability *hostReach = [Reachability reachabilityForInternetConnection];
     NetworkStatus netStatus = [hostReach currentReachabilityStatus];
     return !(netStatus == NotReachable);*/
    
    Reachability *hostReachable = [Reachability reachabilityWithHostName: @"www.apple.com"];
    BOOL isHostAvailable;
    NetworkStatus hostStatus = [hostReachable currentReachabilityStatus];
    switch (hostStatus)
    {
        case NotReachable:
        {
            NSLog(@"A gateway to the host server is down.");
            isHostAvailable = NO;
            
            break;
        }
        case ReachableViaWiFi:
        {
            NSLog(@"A gateway to the host server is working via WIFI.");
            isHostAvailable = YES;
            
            break;
        }
        case ReachableViaWWAN:
        {
            NSLog(@"A gateway to the host server is working via WWAN.");
            isHostAvailable = YES;
            
            break;
        }
    }
    return isHostAvailable;
    
}

-(BOOL)isNetAvalable
{
    Reachability *internetReachable = [Reachability reachabilityForInternetConnection];
    BOOL isNetAvalable;
    NetworkStatus internetStatus = [internetReachable currentReachabilityStatus];
    switch (internetStatus)
    {
        case NotReachable:
        {
            NSLog(@"The internet is down.");
            isNetAvalable = NO;
            break;
        }
        case ReachableViaWiFi:
        {
            NSLog(@"The internet is working via WIFI.");
            isNetAvalable = YES;
            break;
        }
        case ReachableViaWWAN:
        {
            NSLog(@"The internet is working via WWAN.");
            isNetAvalable = YES;
            break;
        }
    }
    return isNetAvalable;
    
}

-(void)addLoadingView
{
    NSLog(@"add");
	if ([_window viewWithTag:666]==nil)
	{
		loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		loadingView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
		[loadingView setTag:666];
		[_window addSubview:loadingView];
		[loadingView release];
		
		UIActivityIndicatorView * act = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
		act.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
		[act startAnimating];
		act.center = loadingView.center;
		[loadingView addSubview:act];
		[act release];
	}
}
-(void)remLoadingView
{
    NSLog(@"remove");
	if ([_window viewWithTag:666]!=nil)
		[loadingView removeFromSuperview];
}



- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
