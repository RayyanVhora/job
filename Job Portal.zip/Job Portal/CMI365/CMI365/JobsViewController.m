//
//  JobsViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "JobsViewController.h"
#import "Toast+UIView.h"
#import "ActivejobsViewController.h"
#import "ArchiveViewController.h"
@interface JobsViewController ()

@end

@implementation JobsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    dc=[[LLDataControll alloc]init];
    mc=[[ModelClass alloc]init];
    
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
            
            [mc newjobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] selector:@selector(didGetNewjobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }

    }
    
    // Do any additional setup after loading the view from its nib.
}

-(void)didGetNewjobs:(NSDictionary*)dic{
    //NSLog(@"dic-->%@",dic);
    
    if ([[NSArray arrayWithArray:[[dic valueForKey:@"docket"] valueForKey:@"docketNo"] ] count]>=1) {
         [self.view makeToast:[NSString stringWithFormat:@"New jobs(%d)",[[NSArray arrayWithArray:[[dic valueForKey:@"docket"] valueForKey:@"docketNo"] ] count]]
                duration:2.0
                position:@"bottom"];
      
        AudioServicesPlaySystemSound (1002);
        
        
           }
    
    else{
        [self.view makeToast:@"No New job avalable"
                    duration:2.0
                    position:@"bottom"];
        
    }
   
    
}
- (IBAction)activejobs:(UIButton *)sender {
    
    ActivejobsViewController *listing=[[ActivejobsViewController alloc]initWithNibName:@"ActivejobsViewController" bundle:nil];
    [self.navigationController pushViewController:listing animated:YES];
     
   }


- (IBAction)newJobs:(id)sender {
    JobListingViewController *listing=[[JobListingViewController alloc]initWithNibName:@"JobListingViewController" bundle:nil];
    [self.navigationController pushViewController:listing animated:YES];
    
}
- (IBAction)archivejobs:(UIButton *)sender {
    
    ArchiveViewController *listing=[[ArchiveViewController alloc]initWithNibName:@"ArchiveViewController" bundle:nil];
    [self.navigationController pushViewController:listing animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)logout:(id)sender {
    [dc deleteData];
    LoginViewController *login = [[LoginViewController alloc]initWithNibName:@"LoginViewController" bundle:nil];
    [self.navigationController pushViewController:login animated:YES];
}
@end
