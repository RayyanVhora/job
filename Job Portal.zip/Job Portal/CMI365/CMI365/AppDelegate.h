//
//  AppDelegate.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"
@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UIView *loadingView;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIView *loadingView;
@property (strong, nonatomic) ViewController *viewController;


-(void)addLoadingView;
-(void)remLoadingView;
-(BOOL)isHostAvailable;
-(BOOL)isNetAvalable;

@end
