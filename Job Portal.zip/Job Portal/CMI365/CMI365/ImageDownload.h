//
//  ImageDownload.h
//  sinemaApp
//
//  Created by Patrascu Raluca on 4/3/10.
//  Copyright 2010 home. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ImageDownload : UIView {

	NSString *idd;
	NSString *url;
	NSString *type;
	
	UIActivityIndicatorView *activity;
	UIImageView *image;
	int dataDidLoad;
}
@property(nonatomic,retain)	NSString *type;
@property(nonatomic,retain)	NSString *url;
@property(nonatomic,retain)	NSString *idd;
@end
