//
//  JobListingViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChooseOptionViewController.h"
#import "LLDataControll.h"
#import "AppDelegate.h"
#import "ModelClass.h"
@interface JobListingViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{

    IBOutlet UITableView *tblListing;
    NSMutableArray *jobArray;
    NSMutableArray *accountArray;
    NSMutableArray *docketNoArray;
    
    LLDataControll *dc;
    AppDelegate *mainDelegate;
    ModelClass *mc;
    IBOutlet UIView *optionView;

}

@end
