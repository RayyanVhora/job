//
//  ModelClass.m
//  APITest
//
//  Created by Evgeny Kalashnikov on 03.12.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ModelClass.h"
#import "SBJson.h"
#import "ASIFormDataRequest.h"

@implementation ModelClass

@synthesize delegate = _delegate;
@synthesize temp;
@synthesize success;
@synthesize returnData = _returnData;
bool isactive;
- (id)init
{
    self = [super init];
    if (self) {
        parser = [[SBJsonParser alloc] init];
        success = NO;
        drk = [[DarckWaitView alloc] initWithDelegate:nil andInterval:0.1 andMathod:nil];
        drkSignUp = [[DarckWaitView alloc] initWithDelegate:nil andInterval:0.1 andMathod:nil];
        dc=[[LLDataControll alloc]init];
    }
    
    return self;
}



- (void) signIn:(NSString *)email password:(NSString *)pasw selector:(SEL)sel {
    if ([pasw length]) {
        seignInSel = sel;
        NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/user_login.php"];    
        ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
        [request setRequestMethod:@"POST"];
        [request setPostValue:email forKey:@"username"];
        [request setPostValue:pasw forKey:@"pass"];
        [request setDelegate:self];
        [request startAsynchronous];
        [drk showWithMessage:nil];
        
    } else {
        UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"Failed!" message:@"Incorest data!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [al show];
        [al release];
    }
}





-(void)setPoints:(NSString *)user_id{
    
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/callback_flurry.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:@"25" forKey:@"reward"];
   
     [request setPostValue:user_id forKey:@"uid"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}


-(void)ForgotPass:(NSString*)email selector:(SEL)sel{
    
    ForgotPass =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/forget_pass.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
  
    [request setPostValue:email forKey:@"email"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)callbackGainPoints:(NSString*)Userid Type:(NSString*)type selector:(SEL)sel{
    
    callbackGainPoints =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/callback_gain_points.php"];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:Userid forKey:@"userid"];
    [request setPostValue:type forKey:@"type"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
}

-(void)noReferralUser:(NSString*)Userid selector:(SEL)sel{
    
    noReferralUser =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/no_referral_user.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:Userid forKey:@"userid"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
}


-(void)EnterContest:(NSString*)email ContestId:(NSString*)contestid UserId:(NSString*)userid CardQuntity:(NSString*)card selector:(SEL)sel{
    
    EnterContest =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/contest_user_new.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    
    [request setPostValue:userid forKey:@"user_id"];
    [request setPostValue:contestid forKey:@"contest_id"];
    [request setPostValue:card forKey:@"number_entries"];
    [request setPostValue:email forKey:@"mail_address"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}




-(void) TodayPrice:(SEL)sel{
    
    TodayPrice =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/get_contest.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void) GetCard:(NSString *)userid selector:(SEL)sel{
    
    GetCard =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/get_cards.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:userid forKey:@"user_id"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}


-(void) ChangePass:(NSString *)userid PassWord:(NSString *)password selector:(SEL)sel{
    
    ChangePass =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/change_pass.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:userid forKey:@"userid"];
    [request setPostValue:password forKey:@"password"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

//http://www.prizeperday.com/mobile/API/callback_aarki.php?user_id={user_id}&reward={reward}&payout={payout}

-(void) GetPoints:(NSString *)userid{
    NSLog(@"GetPoints");
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/get_points.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    [request setRequestMethod:@"POST"];
    NSLog(@"->%@",userid);
    [request setPostValue:userid forKey:@"user_id"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void) GetPoints:(NSString *)userid Activity:(BOOL)Activity{
    
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/get_points.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
   
    [request setPostValue:userid forKey:@"user_id"];
    [request setDelegate:self];
    [request startAsynchronous];
    if (Activity) [drk showWithMessage:nil];
    
}


-(void) SetPoints:(NSString *)userid Reward:(NSString *)reward{
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/callback_aarki.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:userid forKey:@"user_id"];
     [request setPostValue:reward forKey:@"reward"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}



-(void) ApplyPoints:(NSString *)userid CardId:(NSString *)cardid Completed:(NSString *)completed Chk:(NSString *)chk Email:(NSString *)email PtsApplied:(NSString *)applied PtsRequired:(NSString *)required  selector:(SEL)sel{
    
    Applypoints =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/apply_points.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    
  
   
    [request setPostValue:userid forKey:@"user_id"];
    [request setPostValue:cardid forKey:@"gift_id"];
    [request setPostValue:completed forKey:@"completed"];
    [request setPostValue:chk forKey:@"chk"];
    [request setPostValue:email forKey:@"email"];
    [request setPostValue:applied forKey:@"pts_applied"];
    [request setPostValue:required forKey:@"pts_required"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}



-(void) GetCardDetail:(NSString *)userid Cardid:(NSString *)cardid Chk:(NSString *)chk selector:(SEL)sel{
    
    GetCarddetails =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/get_card_details.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:cardid forKey:@"card_id"];
    [request setPostValue:userid forKey:@"user_id"];
    [request setPostValue:chk forKey:@"chk"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void) MyGifts:(NSString *)userid selector:(SEL)sel{
    
    MyGifts =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/my_gifts.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:userid forKey:@"user_id"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void) EditEmail:(NSString *)userid User_Email:(NSString *)userEmail selector:(SEL)sel{
    
    EditEmail =sel;
    NSURL *url = [NSURL URLWithString:@"http://www.prizeperday.com/mobile/API/edit_email.php"];    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:userid forKey:@"user_id"];
    [request setPostValue:userEmail forKey:@"user_email"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}



- (void) frlist:(NSString *)ide name:(NSString *)nm picture:(NSString *)photo gender:(NSString *)gdr birthday:(NSString *)bdate selector:(SEL)sel {
    
    //NSString *str=[NSString stringWithFormat:@"%@users/friend",serverUrl];
    NSURL *url = [NSURL URLWithString:@"http://peerdevelopment.us/developer/gosnatch/users/friend"];  
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    
    [request setRequestMethod:@"POST"];
    [request setPostValue:ide forKey:@"id"];
    [request setPostValue:nm forKey:@"name"];
    [request setPostValue:photo forKey:@"picture"];
    [request setPostValue:gdr forKey:@"gender"];
    [request setPostValue:bdate forKey:@"birthday"];
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
}


-(void)login:(NSString*)username Password:(NSString*)pass selector:(SEL)sel{
    

   NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/LoginMob.aspx?username=%@&password=%@",API_PATH,username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    Login=sel;
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)newjobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel{
    NSLog(@"newjobs");
    isactive = NO;
    NewJob=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/ActiveDriverDockets.aspx?status=%@&username=%@&password=%@",API_PATH,@"Waiting",username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)confirmORDeclinejobs:(NSString*)username Password:(NSString*)pass Jobnum:(NSString*)num Status:(NSString*)status selector:(SEL)sel{
   
    Confirmjobs=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/ConfirmJob.aspx?status=%@&job_num=%@&username=%@&password=%@",API_PATH,status,num,username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}
-(void)jobDetailOrJobDetail:(NSString*)username Password:(NSString*)pass Jobnum:(NSString*)num Status:(NSString*)status selector:(SEL)sel{
    
    jobDropOrDetail=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/JobDetails.aspx?status=%@&job_num=%@&username=%@&password=%@",API_PATH,status,num,username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}



-(void)activejobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel{
    
    NewJob=sel;
    isactive = YES;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/ActiveDriverDockets.aspx?status=%@&username=%@&password=%@",API_PATH,@"Confirmed",username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)archivejobs:(NSString*)username Password:(NSString*)pass selector:(SEL)sel{
    
    Archivejobs=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/ArchiveDriverDockets.aspx?status=%@&username=%@&password=%@",API_PATH,@"Confirmed",username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)pobSave:(NSString*)username Password:(NSString*)pass job_num:(NSString*)jobnum pob_date:(NSString*)pobdate pob_time:(NSString*)pobtime selector:(SEL)sel{
    
    savepob=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/SavePobDetails.aspx?job_num=%@&pob_date=%@&pob_time=%@&username=%@&password=%@",API_PATH,jobnum,pobdate,pobtime,username,pass]];
    NSLog(@"%@",url);
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}

-(void)podSave:(NSString*)username Password:(NSString*)pass job_num:(NSString*)jobnum job_add_id:(NSString*)jobaddid pob_date:(NSString*)pobdate pob_time:(NSString*)pobtime Sign:(NSString*)sign selector:(SEL)sel{
    
    savepod=sel;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/mobile/SavePodDetails.aspx?job_num=%@&job_add_id=%@&pod_date=%@&pod_time=%@&signed=%@&username=%@&password=%@",API_PATH,jobnum,jobaddid,pobdate,pobtime,sign,username,pass]];
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
    NSLog(@"%@",request.url);
    [request setDelegate:self];
    [request startAsynchronous];
    [drk showWithMessage:nil];
    
}



- (void)requestFailed:(ASIHTTPRequest *)request {
    NSLog(@"Error: %@",[[request error] localizedDescription]);
    
    NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
    UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [al show];
    [al release];
    [drk hide];
    
}


- (BOOL) validateEmail: (NSString *)candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"; 
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex]; 
    return [emailTest evaluateWithObject:candidate];
}

- (void)requestFinished:(ASIHTTPRequest *)request {
    
   // NSLog(@"%@",[request responseString]);
    
    NSString *func = [self getFunc:[request url]];
    
   // NSLog(@"%@\n%@",func,[request responseString]);
    
    
    if ([func isEqual:@"SavePodDetails.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
       // NSLog(@"%@",[request responseString]);
        
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
     //   NSLog(@"%@",[parser objectWithString:[request responseString] error:nil]);
        [self.delegate performSelector:savepod withObject:[request responseString]];
    }
    
    if ([func isEqual:@"SavePobDetails.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
     //   NSLog(@"%@",[request responseString]);
        
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
     //   NSLog(@"%@",[parser objectWithString:[request responseString] error:nil]);
        [self.delegate performSelector:savepob withObject:[request responseString]];
    }
    
    
    if ([func isEqual:@"JobDetails.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
     //   NSLog(@"%@",[request responseString]);
        
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
        NSLog(@"--->%@",resDict);
        [self.delegate performSelector:jobDropOrDetail withObject:resDict];
    }
    
    
    if ([func isEqual:@"ConfirmJob.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
      //  NSLog(@"%@",[request responseString]);
        
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
        NSLog(@"%@",resDict);
        [self.delegate performSelector:Confirmjobs withObject:resDict];
    }
    
    if ([func isEqual:@"LoginMob.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
      
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
      //  NSLog(@"%@",[parser objectWithString:[request responseString] error:nil]);
        
        [self.delegate performSelector:Login withObject:resDict];
    }
    
    if ([func isEqual:@"ActiveDriverDockets.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
      //  NSLog(@"-->%@",[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""]);
        NSMutableString *temp1 = [[NSMutableString alloc]initWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""]];
        
       
        if ([temp1 characterAtIndex:temp1.length-3] != ',') {
            isactive = NO;
        }
        if (isactive) {
            NSUInteger len = temp1.length-3;
            NSString *newString= [temp1 stringByReplacingCharactersInRange:NSMakeRange(len,1) withString:@""];
            NSDictionary *resDict = [parser objectWithString:newString];
               NSLog(@"%@",resDict);
           [self.delegate performSelector:NewJob withObject:resDict];

            
        }else{
        NSDictionary *resDict = [parser objectWithString:temp1];
               NSLog(@"%@",resDict);
        [self.delegate performSelector:NewJob withObject:resDict];
        }
     
        
    }
    
    if ([func isEqual:@"ArchiveDriverDockets.aspx"]) {
        [drk hide];
        self.returnData = [request responseString];
       // NSLog(@"-->%@",[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""]);
        
        NSDictionary *resDict = [parser objectWithString:[[request responseString] stringByReplacingOccurrencesOfString:@"'" withString:@"\""] error:nil];
        
        [self.delegate performSelector:Archivejobs withObject:resDict];
    }
    
    
    if ([func isEqual:@"checkshare.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        
        [self.delegate performSelector:isShare withObject:self];
    }
    
    
    if ([func isEqual:@"checkshare.php"]) {
        [drk hide];
       self.returnData = [request responseString];
        
        [self.delegate performSelector:isShare withObject:self];
    }
    

    if ([func isEqual:@"builds.format"]) {
        
        self.returnData = [request responseString];
        //[self.delegate performSelector:seignUpSel withObject:self];
    }
    
    if ([func isEqual:@"apply_points.php"]) {
        
        [drk hide];
        NSLog(@"apply_points->%@",[request responseString]);
        self.returnData = [request responseString];
        [self.delegate performSelector:Applypoints withObject:self];
    }
    
   
    
    if ([func isEqual:@"callback_flurry.php"]) {
        [drk hide];
        //self.returnData = [request responseString];
        
    }
    
    
    if ([func isEqual:@"callback_aarki.php"]) {
        [drk hide];
        //self.returnData = [request responseString];
        
       
        [self.delegate performSelector:ChangePass withObject:self];
    }
    
    if ([func isEqual:@"change_pass.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:ChangePass withObject:self];
    }
    
    
    if ([func isEqual:@"edit_email.php"]) {
        
       
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:EditEmail withObject:self];
    }
    
    if ([func isEqual:@"callback_gain_points.php"]) {
        
       
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:callbackGainPoints withObject:self];
    }
    
    
    if ([func isEqual:@"no_referral_user.php"]) {
        

        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:noReferralUser withObject:self];
    }
    
    
    
    
    if ([func isEqual:@"user_login.php"]) {
       // NSString *result = [[parser objectWithString:[request responseString] error:nil] objectForKey:@"successful"];
        
        if (![[request responseString]isEqualToString:@"0~0"]) {
            success = YES;
          
        self.returnData = [request responseString];
        [drk hide];
        [self.delegate performSelector:seignInSel withObject:self];
        }
        else {
            success = NO;
            self.returnData = [request responseString];
            [drk hide];
            [self.delegate performSelector:seignInSel withObject:self];
        }
    }
    
    if ([func isEqual:@"user_submission.php"]) {
       
       
        [drkSignUp hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:seignUpSel withObject:self];

    }
    
    
    if ([func isEqual:@"forget_pass.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:ForgotPass withObject:self];
        
    }
    
    if ([func isEqual:@"contest_user_new.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:EnterContest withObject:self];
        
    }
    
    if ([func isEqual:@"get_contest.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:TodayPrice withObject:self];
    }
    
    if ([func isEqual:@"get_cards.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:GetCard withObject:self];
    }
    

    if ([func isEqual:@"my_gifts.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:MyGifts withObject:self];
        
    }
    
    if ([func isEqual:@"get_card_details.php"]) {
        [drk hide];
        self.returnData = [request responseString];
        [self.delegate performSelector:GetCarddetails withObject:self];
    }
    
    if ([func isEqual:@"sub"]) {
        NSDictionary *resDict = [parser objectWithString:[request responseString] error:nil];
        NSString *result = [resDict objectForKey:@"successful"];
        [drkSignUp hide];
        if ([result isEqual:@"true"]) {
            [self.delegate performSelector:subCatSel withObject:[resDict objectForKey:@"result"]];
        } else {
            [self.delegate performSelector:subCatSel withObject:[NSNull null]];
        }
    }
    
    if ([func isEqual:@"sublist"]) {
        NSDictionary *resDict = [parser objectWithString:[request responseString] error:nil];
       
        NSString *result = [resDict objectForKey:@"successful"];
        [drkSignUp hide];
        if ([result isEqual:@"true"]) {
            [self.delegate performSelector:sublistSel withObject:[resDict objectForKey:@"Celebrity"]];
        } else {
            [self.delegate performSelector:sublistSel withObject:[NSNull null]];
        }
    }
    
    if ([func isEqual:@"gosnatch"]) {
        NSDictionary *resDict = [parser objectWithString:[request responseString] error:nil];
      
        NSString *result = [resDict objectForKey:@"successful"];
        [drkSignUp hide];
        if ([result isEqual:@"true"]) {
           
            [self.delegate performSelector:statchSel withObject:[NSNumber numberWithBool:YES]];
        } else {
            
            [self.delegate performSelector:statchSel withObject:[NSNumber numberWithBool:NO]];
        }
    }
    

    if ([func isEqual:@"history"]) {
        NSDictionary *resDict = [parser objectWithString:[request responseString] error:nil];
       
        NSString *result = [resDict objectForKey:@"successful"];
        [drkSignUp hide];
        if ([result isEqual:@"true"]) {
            
            [self.delegate performSelector:historySel withObject:resDict];
        } else {
            [self.delegate performSelector:historySel withObject:[NSNumber numberWithBool:NO]];
        }
    }
    
    if ([func isEqual:@"show"]) {
        NSDictionary *resDict = [parser objectWithString:[request responseString] error:nil];
       // NSLog(@"%@",resDict);
        NSString *result = [resDict objectForKey:@"successful"];
        [drkSignUp hide];
        if ([result isEqual:@"true"]) {
            
            [self.delegate performSelector:celebretySel withObject:resDict];
        } else {
            [self.delegate performSelector:celebretySel withObject:[NSNumber numberWithBool:NO]];
        }
    }
}



- (NSString *) getFunc:(NSURL *)url {
    NSString *str = [NSString stringWithFormat:@"%@",url];
    NSArray *arr = [str componentsSeparatedByCharactersInSet:
                    [NSCharacterSet characterSetWithCharactersInString:@"?"]];
    
    NSString *str1 = [NSString stringWithFormat:@"%@",[arr objectAtIndex:0]];
    NSArray *arr1 = [str1 componentsSeparatedByCharactersInSet:
                    [NSCharacterSet characterSetWithCharactersInString:@"/"]];
    
    return [arr1 lastObject];
}

@end
