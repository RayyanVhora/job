//
//  ViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    
    dc=[[LLDataControll alloc]init];
    
    if ([dc getData]) {
        JobsViewController *jobsview=[[JobsViewController alloc]initWithNibName:@"JobsViewController" bundle:nil];
        [self.navigationController pushViewController:jobsview animated:YES];
    }
    else{
        LoginViewController *login=[[LoginViewController alloc]initWithNibName:@"LoginViewController" bundle:nil];
        
        [self.navigationController pushViewController:login animated:YES];
    }

	// Do any additional setup after loading the view, typically from a nib.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
