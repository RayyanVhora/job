//
//  LoginViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    dc= [[LLDataControll alloc] init];
    mc=[[ModelClass alloc]init];
     self.scrollView.scrollEnabled=NO;
    // Do any additional setup after loading the view from its nib.
}





- (IBAction)logIn:(id)sender {
    if ([txtUserId.text isEqualToString:@""] || [txtPassword.text isEqualToString:@""])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"" message:@"Please Enter UserId and Password." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    else
    {
        
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            [mc login:txtUserId.text Password:txtPassword.text selector:@selector(Islogin:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
       

    }
}

- (void) Islogin:(NSDictionary *)Dic {
    
    if (![[Dic valueForKey:@"message"]isEqualToString:@"error"]) {
    NSArray* myArray = [NSArray arrayWithObjects:txtUserId.text,txtPassword.text, nil];
    [dc setData:[NSMutableArray arrayWithArray:myArray]];
    JobsViewController *jobs=[[JobsViewController alloc]initWithNibName:@"JobsViewController" bundle:nil];
    [self.navigationController pushViewController:jobs animated:YES];
        }
    else {
        NSString *msgname;
        msgname=[[NSString alloc]initWithFormat:@"Invalid Username or Password"];
        UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:msgname delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [al show];
        [al release];
    }
    
}
- (IBAction)txtPasswordStart:(id)sender {
    [self.scrollView setContentOffset:CGPointMake(0, 65) animated:YES];
    [self.scrollView setContentSize:CGSizeMake(320, 600)];
    
}

- (IBAction)txtPasswordDone:(id)sender {
    [self.scrollView setContentOffset:CGPointMake(0, 100) animated:YES];
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    /*if (textField == address) {
     if (mainDelegate==nil) {
     mainDelegate=[[AppDelegate alloc]init];
     }
     [mainDelegate AddAddress];
     }*/
    
    return TRUE;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField: textField up: YES];
    
    /*if (textField == address) {
     }
     else{
     [self animateTextField: textField up: YES];
     }*/
}


- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
    
    
}

- (void) animateTextField: (UITextField*) textField up: (BOOL) up
{
    
    self.scrollView.scrollEnabled=YES;
    
    if (textField ==txtUserId) {
        [self.scrollView setContentOffset:CGPointMake(0, 50) animated:YES];
        [self.scrollView setContentSize:CGSizeMake(320, 590)];
    }
    if (textField ==txtPassword) {
        
        [self.scrollView setContentSize:CGSizeMake(320, 590)];
        
        [self.scrollView setContentOffset:CGPointMake(0, 100) animated:YES];
    }
    
    
    
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];

    [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    self.scrollView.scrollEnabled=NO;
    
	return YES;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [txtUserId release];
    [txtPassword release];
    [lblUserName release];
    [lblPassword release];
    [_scrollView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setScrollView:nil];
    [super viewDidUnload];
}
@end
