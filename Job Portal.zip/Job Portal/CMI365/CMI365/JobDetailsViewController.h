//
//  JobDetailsViewController.h
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JobDetailsViewController : UIViewController<UITableViewDataSource,UITabBarDelegate>
{

    IBOutlet UITableView *tblJobDetail;
    NSMutableArray *hedaing;
    NSMutableArray *hedaing1;
    NSMutableArray *displayarr1;
    NSMutableArray *detail;
    NSMutableArray *dataArray;
    NSMutableDictionary *destDics;
    NSMutableDictionary *PodDics;
    BOOL ispick;
    IBOutlet UILabel *header_lbl;
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil DataArray:(NSArray *)array Ispick:(BOOL)Ispick;

@end
