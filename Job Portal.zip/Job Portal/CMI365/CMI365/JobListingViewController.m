//
//  JobListingViewController.m
//  CMI365
//
//  Created by Peerbits Solution on 03/11/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "JobListingViewController.h"
#import "Toast+UIView.h"
@interface JobListingViewController ()

@end

@implementation JobListingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    dc=[[LLDataControll alloc]init];
    mc=[[ModelClass alloc]init];
    
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
            
            [mc newjobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] selector:@selector(didGetNewjobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }


    jobArray=[[NSMutableArray alloc]initWithArray:[NSArray arrayWithObjects:@"Job 1 Goes Here",@"Job 2 Goes Here",@"Job 3 Goes Here",@"Job 4 Goes Here",@"Job 5 Goes Here",nil]];
    // Do any additional setup after loading the view from its nib.
}

-(void)didGetNewjobs:(NSDictionary*)dic{
    NSLog(@"dic-->%@",dic);
    accountArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"account"]];
    
    docketNoArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"docketNo"]];
    [tblListing reloadData];
    
    if ([accountArray  count]>=1) {
      [tblListing reloadData];
    }
    
    else{
        [self.view makeToast:@"No New job avalable"
                    duration:2.0
                    position:@"bottom"];
        
    }
    
}


- (IBAction)btnBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [docketNoArray count];
}

// Customize the appearance of table view cells.
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    UILabel *lblList = [[UILabel alloc] initWithFrame:CGRectMake(15, 12, 200, 41)];
    lblList.backgroundColor = [UIColor clearColor];
    [lblList setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblList.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    lblList.textAlignment = UITextAlignmentLeft;
    lblList.text = [NSString stringWithFormat:@"%@ - %@",[docketNoArray objectAtIndex:indexPath.row],[accountArray objectAtIndex:indexPath.row]];
    [cell.contentView addSubview:lblList];
    
    
    UIImageView *MyImageView = [[UIImageView alloc] initWithFrame:CGRectMake(290,20, 11, 15)];
    MyImageView.image = [UIImage imageNamed:@"Arrow@2x.png"];
    [cell.contentView addSubview: MyImageView];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblListing deselectRowAtIndexPath:indexPath animated:YES];
    
    /*ChooseOptionViewController *option=[[ChooseOptionViewController alloc]initWithNibName:@"ChooseOptionViewController" bundle:nil];
    [self.navigationController pushViewController:option animated:YES];*/
    
    //optionView.frame=CGRectMake(0,0,320,460);
    optionView.clipsToBounds=YES;
    optionView.tag=[[docketNoArray objectAtIndex:indexPath.row] integerValue];
    [self.view addSubview:optionView];
    
    
}
- (IBAction)conformbtn:(UIButton *)sender {
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
          
            [mc confirmORDeclinejobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:[NSString stringWithFormat:@"%d",optionView.tag] Status:@"Confirmed" selector:@selector(didConfirmjobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
    [optionView removeFromSuperview];

}

-(void)didConfirmjobs:(NSMutableDictionary*)dic{
    [self.view makeToast:[dic valueForKey:@"message"]];
    
}

- (IBAction)declinebtn:(UIButton *)sender {
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[NSString stringWithFormat:@"%d",optionView.tag]);
            
            [mc confirmORDeclinejobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:[NSString stringWithFormat:@"%d",optionView.tag] Status:@"Declined" selector:@selector(didDeclinedjobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
    [optionView removeFromSuperview];
}
-(void)didDeclinedjobs:(NSMutableDictionary*)dic{
     [self.view makeToast:[dic valueForKey:@"message"]];
    
    
}
- (IBAction)closeOptionView:(UIButton *)sender {
    
    [optionView removeFromSuperview];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblListing release];
    [optionView release];
    [super dealloc];
}
- (void)viewDidUnload {
    [optionView release];
    optionView = nil;
    [super viewDidUnload];
}
@end
