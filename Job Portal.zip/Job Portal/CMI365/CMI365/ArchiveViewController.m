//
//  ArchiveViewController.m
//  CMI365
//
//  Created by iMac on 11/6/12.
//  Copyright (c) 2012 Peerbits Solution. All rights reserved.
//

#import "ArchiveViewController.h"
#import "Toast+UIView.h"
#import "JobDetailsViewController.h"
@interface ArchiveViewController ()

@end

@implementation ArchiveViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    dc=[[LLDataControll alloc]init];
    mc=[[ModelClass alloc]init];
    
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
            
            [mc archivejobs:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] selector:@selector(didGetarchivejobs:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    // Do any additional setup after loading the view from its nib.
}



-(void)didGetarchivejobs:(NSDictionary*)dic{
    NSLog(@"dic-->%@",dic);
    accountArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"account"]];
    
    docketNoArray=[[NSMutableArray alloc ]initWithArray:[[dic valueForKey:@"docket"] valueForKey:@"docketNo"]];
    [tblListing reloadData];
    
    if ([accountArray  count]>=1) {
        [tblListing reloadData];
    }
    
    else{
        [self.view makeToast:@"No Active job avalable"
                    duration:2.0
                    position:@"bottom"];
        
    }
    
}



- (IBAction)btnBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [docketNoArray count];
}

// Customize the appearance of table view cells.
-(UITableViewCell *)tableView:(UITableView *)tableView
        cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    UILabel *lblList = [[UILabel alloc] initWithFrame:CGRectMake(15, 12, 200, 41)];
    lblList.backgroundColor = [UIColor clearColor];
    [lblList setTextColor:[UIColor colorWithRed:62.0/255.0 green:62.0/255.0 blue:62.0/255.0 alpha:1.0]];
    lblList.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
    lblList.textAlignment = UITextAlignmentLeft;
    lblList.text = [NSString stringWithFormat:@"%@ - %@",[docketNoArray objectAtIndex:indexPath.row],[accountArray objectAtIndex:indexPath.row]];
    [cell.contentView addSubview:lblList];
    
    
    UIImageView *MyImageView = [[UIImageView alloc] initWithFrame:CGRectMake(290,20, 11, 15)];
    MyImageView.image = [UIImage imageNamed:@"Arrow@2x.png"];
    [cell.contentView addSubview: MyImageView];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblListing deselectRowAtIndexPath:indexPath animated:YES];
    
    /*ChooseOptionViewController *option=[[ChooseOptionViewController alloc]initWithNibName:@"ChooseOptionViewController" bundle:nil];
     [self.navigationController pushViewController:option animated:YES];*/
    
   // optionview.frame=CGRectMake(0,0,320,460);
    optionview.clipsToBounds=YES;
    optionview.tag=[[docketNoArray objectAtIndex:indexPath.row] integerValue];
    [self.view addSubview:optionview];
    
    
}


- (IBAction)Pick_Detail:(UIButton *)sender {
    
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[[dc getData] objectAtIndex:0]);
            
            
            [mc jobDetailOrJobDetail:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:[NSString stringWithFormat:@"%d",optionview.tag] Status:@"Confirmed" selector:@selector(didjobDetail:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
    [optionview removeFromSuperview];
    
}

-(void)didjobDetail:(NSMutableDictionary*)dic{
    JobDetailsViewController *jobdetail=[[JobDetailsViewController alloc]initWithNibName:@"JobDetailsViewController" bundle:nil DataArray:[NSArray arrayWithArray:[dic valueForKey:@"Details"]]Ispick:YES];
    
    [self.navigationController pushViewController:jobdetail animated:YES];
    
}

- (IBAction)Drop_Detail:(UIButton *)sender {
    if ([dc getData]) {
        if([DELEGATE isHostAvailable]&&[DELEGATE isNetAvalable]){
            [mc setDelegate:self];
            NSLog(@"sdasd%@",[NSString stringWithFormat:@"%d",optionview.tag]);
            
            [mc jobDetailOrJobDetail:[[dc getData] objectAtIndex:0] Password:[[dc getData] objectAtIndex:1] Jobnum:[NSString stringWithFormat:@"%d",optionview.tag] Status:@"Confirmed" selector:@selector(didjobDrop:)];
        }
        else {
            NSString *bookmarkedName=[NSString stringWithFormat:@"Failed to connect . Check internet connection!"];
            UIAlertView *al = [[UIAlertView alloc] initWithTitle:@"" message:bookmarkedName delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [al show];
            [al release];
        }
        
    }
    
    [optionview removeFromSuperview];
}
-(void)didjobDrop:(NSMutableDictionary*)dic{
    
    //NSLog(@"-->%@",dic);
    
   // NSLog(@"-->%@",[[dic valueForKey:@"Details"] valueForKey:@"Destination"]);
     //NSLog(@"-->%@",[NSArray arrayWithArray:[dic valueForKey:@"Details"]]);
    
    JobDetailsViewController *jobdetail=[[JobDetailsViewController alloc]initWithNibName:@"JobDetailsViewController" bundle:nil DataArray:[NSArray arrayWithArray:[dic valueForKey:@"Details"]]Ispick:NO];
    
    [self.navigationController pushViewController:jobdetail animated:YES];
    
}



- (IBAction)CloseOptionView:(UIButton *)sender {
    
    [optionview removeFromSuperview];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblListing release];
    [optionview release];
    [super dealloc];
}
- (void)viewDidUnload {
    [tblListing release];
    tblListing = nil;
    [optionview release];
    optionview = nil;
    [super viewDidUnload];
}
@end
